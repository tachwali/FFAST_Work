#include "input.h"

#include <algorithm>
#include <iostream>
#include <cmath>
#include <fstream>

Input::Input(Chrono* newChrono, const Config* newConfig): Step(newChrono, newConfig)
{
}

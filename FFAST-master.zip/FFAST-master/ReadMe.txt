This folder contains the following:

The original FFAST files in the following folders:
1- FFAST_Doc
2- include
3- MATLAB
4- src

Note: a slight modification is made to chrono.cpp in order to make it build in VS system
TODO: Port chrono.cpp to work under windows

The following folders are added:
1- bin: it contains a pre-built FFAST 64 bit executable. Refer to the manual in FFAST_Doc folder to use it
2- lib: contains the FFTW source in (fftw-3.3-libs) and pre-built 64 bit libraries in (FFTW3)
3- VSProject: contain the FFAST VS solution which can be used to debug the algorithm


Getting started:
----------------
Go to command prompt :
1- CD to the bin directory
2- Run the FFAST exe , for example Type : FFAST.exe -a -n 124950 -s 10 -k 10 -i 30

